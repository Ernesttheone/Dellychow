# Deli Chow video system rebuild

## What changed

- New chef uploads use Firebase Storage resumable uploads instead of the Express server's local disk.
- Each uploaded object is stored under `videos/{chefUid}/{videoId}.{ext}`.
- The exact Firebase download URL and Storage object path are saved on the Firestore video record.
- Upload progress is reported from Firebase's actual byte-transfer events.
- If Firestore publishing fails after upload, the new Storage object is removed as cleanup.
- Deleting a video record also attempts to delete its associated Storage object.
- Existing `/api/videos/stream/...`, `/uploads/videos/...`, and `dellychow-video://` records remain supported as legacy URLs; they are not silently replaced with another video.
- Existing recipe, profile, chat, favourites, subscriptions, and other app features were not intentionally changed.

## Required Firebase deployment step

The code alone cannot activate Firebase Storage rules in the live Firebase project. From this project directory, deploy the rules with:

```bash
firebase deploy --project charged-art-wghtt --only storage
```

If you also manage Firestore rules from this repository, deploy both with `firebase deploy --project charged-art-wghtt --only firestore:rules,storage`. Confirm the Firebase CLI is logged into the correct project (`charged-art-wghtt`) before deploying.

The Firebase Storage bucket must be enabled for the configured project and billing/plan limits must permit the intended upload sizes. Verify the bucket exists before deployment; this source-code rebuild cannot enable the bucket or deploy cloud rules on your behalf. The new rule permits signed-in owners to upload video files up to 250 MiB and permits public reads, matching the current public video discovery model.

## Playback compatibility

The player uses the original file URL and the browser's native video decoder. MP4 encoded with H.264 video and AAC audio is the safest cross-device format. WebM support depends on browser/device codec support. MOV is accepted as an upload container but is not guaranteed to play on every Android/browser combination. This rebuild does not transcode media; a transcoding service would be needed to guarantee a standardized rendition for every uploaded codec.

## Existing uploads

Legacy local-disk URLs are retained for backwards compatibility, but files on an ephemeral hosting filesystem are not made persistent by this change. Existing legacy video files must be migrated to Firebase Storage separately if their current host does not preserve the `public/uploads/videos` directory. New uploads will not depend on that directory.

## Build and verification status

The changed TypeScript/TSX files passed a syntax-transpilation check. A full dependency-backed application build was not completed in this environment because dependency installation did not finish; run `npm install` (or the package manager used by your project) followed by `npm run build` before publishing.

## Verification checklist

1. Deploy Storage rules to the correct Firebase project.
2. Sign in as a chef and upload a short MP4 encoded with H.264/AAC.
3. Confirm upload progress reaches 100% and a Firestore record is created with a Firebase Storage URL and `storagePath`.
4. Open the published video from a second signed-in food-lover account and from a logged-out browser if the product's existing visibility rules allow it.
5. Test play, pause, seeking, reload, and playback on Android, iOS/Safari, and desktop browsers.
6. Delete a test video and confirm its Storage object is removed.
