/**
 * Deli Chow video storage. New uploads go to Firebase Storage (persistent,
 * resumable, and independent of the web-server filesystem). Existing legacy
 * server URLs remain readable for backwards compatibility.
 */
import { ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { auth, storage } from './firebase';

export interface VideoUploadResult {
  success: boolean;
  id: string;
  filename: string;
  url: string;
  size: number;
  storagePath: string;
}

export interface VideoValidationResult {
  valid: boolean;
  error?: string;
  detectedFormat?: string;
}

const MAX_VIDEO_SIZE_BYTES = 250 * 1024 * 1024; // 250 MB
const SUPPORTED_VIDEO_FORMATS = ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-m4v'];

/**
 * Validate video file format and size before upload.
 */
export function validateVideoFile(file: File): VideoValidationResult {
  if (!file) {
    return { valid: false, error: 'No video file selected.' };
  }

  if (file.size > MAX_VIDEO_SIZE_BYTES) {
    const sizeMb = (file.size / (1024 * 1024)).toFixed(1);
    return {
      valid: false,
      error: `Video size (${sizeMb} MB) exceeds maximum allowed size of 250 MB. Please compress or select a shorter video.`
    };
  }

  const name = file.name.toLowerCase();
  const type = file.type.toLowerCase();

  const isSupportedType = SUPPORTED_VIDEO_FORMATS.some(f => type.includes(f));
  const isSupportedExt = name.endsWith('.mp4') || name.endsWith('.webm') || name.endsWith('.mov') || name.endsWith('.m4v');

  if (!isSupportedType && !isSupportedExt) {
    return {
      valid: false,
      error: 'Unsupported video format. Please upload an MP4, WebM, or QuickTime (MOV) video.'
    };
  }

  const detectedFormat = name.endsWith('.webm') || type.includes('webm') 
    ? 'WebM' 
    : name.endsWith('.mov') || type.includes('quicktime') 
    ? 'QuickTime (MOV)' 
    : 'MP4';

  return { valid: true, detectedFormat };
}

/**
 * Upload the exact original video to Firebase Storage with resumable progress.
 * No local-server fallback is used: a failed cloud upload must fail visibly.
 */
export function uploadVideoToServer(
  blob: Blob,
  filename: string,
  videoId: string,
  onProgress?: (percent: number) => void
): Promise<VideoUploadResult> {
  return new Promise((resolve, reject) => {
    const user = auth.currentUser;
    if (!user) {
      reject(new Error('You must be signed in to upload a video. Please sign in and try again.'));
      return;
    }

    const safeName = filename.split(/[\\/]/).pop() || 'video.mp4';
    const extension = safeName.match(/\.(mp4|webm|mov|m4v)$/i)?.[0]?.toLowerCase() ||
      (blob.type.includes('webm') ? '.webm' : blob.type.includes('quicktime') ? '.mov' : '.mp4');
    if (blob.size > MAX_VIDEO_SIZE_BYTES) {
      reject(new Error('Video exceeds the 250 MB upload limit. Please choose a smaller file.'));
      return;
    }
    const fallbackContentType = extension === '.webm' ? 'video/webm' : extension === '.mov' ? 'video/quicktime' : extension === '.m4v' ? 'video/x-m4v' : 'video/mp4';
    const contentType = blob.type.startsWith('video/') ? blob.type : fallbackContentType;
    const storagePath = `videos/${user.uid}/${videoId}${extension}`;
    const videoRef = ref(storage, storagePath);
    const task = uploadBytesResumable(videoRef, blob, {
      contentType,
      cacheControl: 'public,max-age=3600',
      customMetadata: {
        ownerUid: user.uid,
        videoId,
        originalFilename: safeName
      }
    });

    task.on('state_changed',
      snapshot => {
        if (onProgress && snapshot.totalBytes > 0) {
          onProgress(Math.min(99, Math.round(snapshot.bytesTransferred / snapshot.totalBytes * 100)));
        }
      },
      error => reject(new Error(`Video upload failed: ${error.message}`)),
      async () => {
        try {
          const url = await getDownloadURL(task.snapshot.ref);
          onProgress?.(100);
          resolve({ success: true, id: videoId, filename: `${videoId}${extension}`, url, size: blob.size, storagePath });
        } catch (error) {
          try { await deleteObject(task.snapshot.ref); } catch { /* Best-effort cleanup of an object without a published URL. */ }
          reject(new Error(`Video uploaded but its playback URL could not be created: ${error instanceof Error ? error.message : String(error)}`));
        }
      }
    );
  });
}

/** Remove an uploaded object if publishing its Firestore record fails. */
export async function deleteUploadedVideo(storagePath: string): Promise<void> {
  if (!storagePath) return;
  await deleteObject(ref(storage, storagePath));
}

/**
 * Extract exact video duration (in minutes) and high-resolution thumbnail from original video.
 */
export function extractVideoMetadataAndThumbnail(
  fileOrBlob: Blob
): Promise<{ durationMinutes: number; thumbnailUrl: string }> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;

    const tempUrl = URL.createObjectURL(fileOrBlob);
    video.src = tempUrl;

    const cleanup = () => {
      URL.revokeObjectURL(tempUrl);
      video.remove();
    };

    const timeout = setTimeout(() => {
      cleanup();
      // Graceful fallback with standard 10m duration if browser canvas extraction takes too long
      resolve({
        durationMinutes: 10,
        thumbnailUrl: ''
      });
    }, 15000);

    video.onloadedmetadata = () => {
      const durationSeconds = video.duration || 60;
      const durationMinutes = Math.max(1, Math.round(durationSeconds / 60));

      // Seek to 1 second into video (or 10% for short clips) to capture an active cooking frame
      video.currentTime = Math.min(1.0, durationSeconds * 0.1);
    };

    video.onseeked = () => {
      clearTimeout(timeout);
      try {
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 360;

        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const thumbnailUrl = canvas.toDataURL('image/jpeg', 0.85);
          const durationSeconds = video.duration || 60;
          const durationMinutes = Math.max(1, Math.round(durationSeconds / 60));
          cleanup();
          resolve({ durationMinutes, thumbnailUrl });
          return;
        }
      } catch (err) {
        console.warn('Canvas frame capture notice:', err);
      }

      cleanup();
      resolve({
        durationMinutes: Math.max(1, Math.round((video.duration || 60) / 60)),
        thumbnailUrl: ''
      });
    };

    video.onerror = () => {
      clearTimeout(timeout);
      cleanup();
      resolve({
        durationMinutes: 10,
        thumbnailUrl: ''
      });
    };
  });
}

/**
 * Resolve any video URL into a direct, standard streaming URL.
 * NEVER substitutes an AI video or generic default video.
 */
export async function resolveVideoUrl(url: string, videoId?: string): Promise<string> {
  if (!url) return '';

  const cleanUrl = url.trim();

  // Map static uploads paths directly to byte-range stream endpoint
  if (cleanUrl.startsWith('/public/uploads/videos/')) {
    const filename = cleanUrl.replace('/public/uploads/videos/', '');
    return `/api/videos/stream/${filename}`;
  }
  if (cleanUrl.startsWith('public/uploads/videos/')) {
    const filename = cleanUrl.replace('public/uploads/videos/', '');
    return `/api/videos/stream/${filename}`;
  }
  if (cleanUrl.startsWith('/uploads/videos/')) {
    const filename = cleanUrl.replace('/uploads/videos/', '');
    return `/api/videos/stream/${filename}`;
  }

  // Direct standard URLs (HTTP, HTTPS, direct stream, blobs, data)
  if (
    cleanUrl.startsWith('http://') ||
    cleanUrl.startsWith('https://') ||
    cleanUrl.startsWith('/api/videos/stream/') ||
    cleanUrl.startsWith('/uploads/') ||
    cleanUrl.startsWith('blob:') ||
    cleanUrl.startsWith('data:')
  ) {
    return cleanUrl;
  }

  // Normalize legacy dellychow-video:// protocol to direct server streaming path
  if (cleanUrl.startsWith('dellychow-video://')) {
    const rawPath = cleanUrl.replace('dellychow-video://', '');
    const [cleanId, queryString] = rawPath.split('?');
    const params = new URLSearchParams(queryString || '');
    const effectiveId = cleanId || videoId || params.get('vid') || 'video';
    return `/api/videos/stream/${effectiveId}.mp4`;
  }

  // Bare legacy IDs are supported only when an explicit video ID was supplied.
  if (/^[a-zA-Z0-9_-]+$/.test(cleanUrl) && videoId) {
    return `/api/videos/stream/${cleanUrl}.mp4`;
  }

  return cleanUrl;
}

/**
 * Check if a server stream exists.
 */
export async function checkServerStreamExists(streamUrl: string): Promise<boolean> {
  if (!streamUrl || streamUrl.startsWith('blob:') || streamUrl.startsWith('data:')) return true;
  try {
    const res = await fetch(streamUrl, { method: 'HEAD' });
    return res.ok;
  } catch {
    return false;
  }
}

/**
 * Sync legacy video records to standard server URLs so all users and food lovers can play them directly.
 */
export async function syncPublishedVideosToServer(
  videos: Array<{ id: string; videoUrl: string; title?: string }>,
  onSynced?: (videoId: string, newUrl: string) => void
): Promise<void> {
  for (const v of videos) {
    if (v.videoUrl && v.videoUrl.startsWith('dellychow-video://')) {
      const cleanId = v.videoUrl.replace('dellychow-video://', '').split('?')[0];
      const newUrl = `/api/videos/stream/${cleanId}.mp4`;
      if (onSynced) {
        onSynced(v.id, newUrl);
      }
    }
  }
}

// Backwards-compatible stubs for older components
export async function saveVideoBlob(
  blob: Blob,
  filename?: string
): Promise<{ id: string; storageUrl: string; blobUrl: string }> {
  const id = `vid_${Date.now()}`;
  const blobUrl = URL.createObjectURL(blob);
  return {
    id,
    storageUrl: `/api/videos/stream/${id}.mp4`,
    blobUrl
  };
}

export async function getVideoBlob(_id: string): Promise<Blob | null> {
  return null;
}

export async function uploadVideoChunksToFirestore(_videoId: string, _blob: Blob): Promise<number> {
  return 0;
}

export async function backupStoredVideos(): Promise<any[]> {
  return [];
}

export async function clearAllStoredVideos(): Promise<{ clearedCount: number }> {
  return { clearedCount: 0 };
}

