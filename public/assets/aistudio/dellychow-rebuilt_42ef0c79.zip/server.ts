import express from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;
  const UPLOADS_DIR = path.resolve(__dirname, 'public/uploads/videos');

  // Ensure uploads directory exists
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }

  // New uploads go through authenticated Firebase Storage from the client.
  // Retire the old unauthenticated local-disk upload endpoint; keep legacy GET
  // streaming below so already-published local URLs can still be read.
  app.post('/api/videos/upload', (_req, res) => {
    return res.status(410).json({
      error: 'Local video uploads have been retired. Please use the Firebase Storage upload flow.'
    });
  });

  // Stream endpoints CORS and public access middleware
  const setVideoCorsHeaders = (res: express.Response) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Range, Content-Type, Accept');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Content-Length, Accept-Ranges, Content-Type');
    res.setHeader('Cache-Control', 'public, max-age=3600');
  };

  // OPTIONS handler for cross-origin preflight checks
  app.options('/api/videos/stream/:filename', (req, res) => {
    setVideoCorsHeaders(res);
    return res.status(204).end();
  });

  // Check if a video stream exists on server
  app.head('/api/videos/stream/:filename', (req, res) => {
    setVideoCorsHeaders(res);
    const rawFilename = path.basename(req.params.filename);
    const baseName = rawFilename.replace(/\.(mp4|webm|mov|m4v)$/i, '');
    let filePath = path.join(UPLOADS_DIR, rawFilename);

    if (!fs.existsSync(filePath)) {
      const candidates = [`${baseName}.mp4`, `${baseName}.webm`, `${baseName}.mov`, `${baseName}.m4v`];
      for (const cand of candidates) {
        const testPath = path.join(UPLOADS_DIR, cand);
        if (fs.existsSync(testPath)) {
          filePath = testPath;
          break;
        }
      }
    }

    // Strict separation: never substitute requested video with any default or AI-generated video
    if (fs.existsSync(filePath)) {
      const stat = fs.statSync(filePath);
      const ext = path.extname(filePath).toLowerCase();
      const mimeType = ext === '.webm' ? 'video/webm' : ext === '.mov' ? 'video/quicktime' : 'video/mp4';
      res.setHeader('Content-Length', stat.size);
      res.setHeader('Accept-Ranges', 'bytes');
      res.setHeader('Content-Type', mimeType);
      return res.status(200).end();
    }
    return res.status(404).end();
  });

  // Stream video with HTTP Range Requests (smooth seeking, iOS/Safari/Android/Desktop support)
  app.get('/api/videos/stream/:filename', (req, res) => {
    setVideoCorsHeaders(res);
    const rawFilename = path.basename(req.params.filename);
    const baseName = rawFilename.replace(/\.(mp4|webm|mov|m4v)$/i, '');
    let filePath = path.join(UPLOADS_DIR, rawFilename);

    // If extension wasn't specified or mismatch, look for matching video file
    if (!fs.existsSync(filePath)) {
      const candidates = [`${baseName}.mp4`, `${baseName}.webm`, `${baseName}.mov`, `${baseName}.m4v`];
      for (const cand of candidates) {
        const testPath = path.join(UPLOADS_DIR, cand);
        if (fs.existsSync(testPath)) {
          filePath = testPath;
          break;
        }
      }
    }

    // Strict separation: never substitute requested video with any default or AI-generated video
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'Video file not found on server.' });
    }

    const stat = fs.statSync(filePath);
    const fileSize = stat.size;
    const range = req.headers.range;

    const ext = path.extname(filePath).toLowerCase();
    const mimeType = ext === '.webm' 
      ? 'video/webm' 
      : ext === '.mov' 
      ? 'video/quicktime' 
      : 'video/mp4';

    if (range) {
      // Support standard single byte ranges, including suffix ranges, and reject
      // malformed/out-of-bounds requests instead of crashing the stream handler.
      const match = /^bytes=(\d*)-(\d*)$/.exec(range.trim());
      if (!match || (!match[1] && !match[2])) {
        res.setHeader('Content-Range', `bytes */${fileSize}`);
        return res.status(416).end();
      }

      let start: number;
      let end: number;
      if (!match[1]) {
        const suffixLength = Number(match[2]);
        if (!Number.isSafeInteger(suffixLength) || suffixLength <= 0) {
          res.setHeader('Content-Range', `bytes */${fileSize}`);
          return res.status(416).end();
        }
        start = Math.max(0, fileSize - suffixLength);
        end = fileSize - 1;
      } else {
        start = Number(match[1]);
        end = match[2] ? Number(match[2]) : fileSize - 1;
      }

      if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || start >= fileSize || end < start) {
        res.setHeader('Content-Range', `bytes */${fileSize}`);
        return res.status(416).end();
      }
      end = Math.min(end, fileSize - 1);
      res.writeHead(206, {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': end - start + 1,
        'Content-Type': mimeType,
      });
      const file = fs.createReadStream(filePath, { start, end });
      file.on('error', (error) => {
        console.error('[Video Stream] Read error:', error);
        if (!res.headersSent) res.status(500).end();
        else res.destroy(error);
      });
      file.pipe(res);
    } else {
      const head = {
        'Content-Length': fileSize,
        'Content-Type': mimeType,
        'Accept-Ranges': 'bytes',
      };
      res.writeHead(200, head);
      fs.createReadStream(filePath).pipe(res);
    }
  });

  // Serve static uploads
  app.use('/uploads/videos', express.static(UPLOADS_DIR));
  app.use('/public/uploads/videos', express.static(UPLOADS_DIR));

  // Social Crawler Preview Middleware for Link Sharing System (WhatsApp, Twitter/X, Facebook, Telegram, etc.)
  app.use(async (req, res, next) => {
    const userAgent = (req.headers['user-agent'] || '').toLowerCase();
    const isBot = /bot|facebookexternalhit|twitterbot|whatsapp|telegrambot|linkedinbot|slackbot|discordbot|googlebot/i.test(userAgent);

    if (isBot && (req.query.video || req.query.v || req.query.chef || req.query.user || req.query.recipe)) {
      const videoId = (req.query.video || req.query.v) as string;
      const chefId = req.query.chef as string;
      const userId = req.query.user as string;
      const recipeId = req.query.recipe as string;

      let title = 'DellyChow | Cooking & Recipe-Sharing Community';
      let description = 'Connect with chefs and food lovers worldwide. Discover artisan recipes and master video classes.';
      const image = 'https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=1200&q=80';
      const shareUrl = `${req.protocol}://${req.get('host')}${req.originalUrl}`;

      if (videoId) {
        title = `Watch Cooking Masterclass on DellyChow`;
        description = `Watch step-by-step culinary techniques and master kitchen skills on DellyChow.`;
      } else if (chefId) {
        title = `Master Chef Profile | DellyChow`;
        description = `Discover handcrafted recipes and culinary masterclasses on DellyChow.`;
      } else if (userId) {
        title = `Food Lover Culinary Profile | DellyChow`;
        description = `Explore culinary honors and favorite dishes on DellyChow.`;
      } else if (recipeId) {
        title = `Artisan Recipe | DellyChow`;
        description = `Discover detailed ingredients and cooking steps on DellyChow.`;
      }

      const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <meta name="description" content="${description}">
  <meta property="og:title" content="${title}">
  <meta property="og:description" content="${description}">
  <meta property="og:image" content="${image}">
  <meta property="og:url" content="${shareUrl}">
  <meta property="og:type" content="website">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${title}">
  <meta name="twitter:description" content="${description}">
  <meta name="twitter:image" content="${image}">
</head>
<body>
  <h1>${title}</h1>
  <p>${description}</p>
  <a href="${shareUrl}">Open on DellyChow</a>
</body>
</html>`;
      return res.status(200).send(html);
    }

    next();
  });

  // Mount Vite in development or serve static build in production
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        host: '0.0.0.0',
        allowedHosts: true,
        hmr: process.env.DISABLE_HMR !== 'true',
        watch: process.env.DISABLE_HMR === 'true' ? null : {}
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist/index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`DellyChow Full-Stack Server active on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
